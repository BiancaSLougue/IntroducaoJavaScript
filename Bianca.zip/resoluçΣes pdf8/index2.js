for (let i = 10; i >= 0; i--) {
    console.log(i);
}

let i = 10;

while (i >= 0) {
    console.log(i);

    i--;
}