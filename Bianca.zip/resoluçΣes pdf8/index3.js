let soma = 0;

for (let i = 0; i <= 100; i += 2) {
    soma += i;
}

console.log(soma);

let soma2 = 0;
let contador = 0;

while (contador <= 100) {
    soma2 += contador;
    contador += 2;
}

console.log(soma2);