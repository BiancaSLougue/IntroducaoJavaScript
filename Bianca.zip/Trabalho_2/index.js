import promptSync from "prompt-sync";
import fs from 'fs';

import { initDatabase } from "./utils.js";





const prompt = promptSync();

const pathCategorias = './data/categorias.json';
const pathLivros = './data/livros.json';
const pathFuncoes = './data/funcoes.json';


initDatabase(pathCategorias);
initDatabase(pathLivros);
initDatabase(pathFuncoes);
//OBS: Validar os dados pra ele não permitir a criação da mesma categoria/... duas vezes
const categorias = JSON.parse(fs.readFileSync(pathCategorias, 'utf-8'));

console.log(`Escolha uma opção:

1. Criar Livro
2. Editar Livro
3. Buscar Livro por Nome
4. Buscar Livro por Categoria
5. Excluir Livro
6. Criar Categoria
7. Editar Categoria
8. Visualizar Categorias
9. Excluir Categoria
10. Sair`);

const opcao = prompt("Opção escolhida: ");

const nome = prompt("Insira o nome da categoria: ");

const categoria = {
    id: categorias.ultimoId,
    nome: nome
}

categorias.dados.push(categoria);
categorias.ultimoId = categorias.ultimoId + 1;

fs.writeFileSync(pathCategorias, JSON.stringify(categorias));

switch (opcao) {
    // 1 - Criar Livro  
    case "1":
        console.log(a + b);
        break;
    // 2 - Editar Livro
    case "2":
        console.log(a - b);
        break;
    // 3 - Buscar Livro por Nome
    case "3":
        console.log(a / b);
        break;
    // 4 - Buscar Livro por Categoria
    case "4":
        console.log(a * b);
        break;
    // 5 - Excluir Livro
    case "5":
        console.log("FIM");
        break;
    // 6 - Criar Categoria
    case "6":
        console.log("FIM");
        break;
    // 7 - Editar Categoria
    case "7":
        console.log("FIM");
        break;
    // 8 - Visualizar Categorias
    case "8":
        console.log("FIM");
        break;
    // 9 - Excluir Categoria  
    case "9":
        console.log("FIM");
        break;
    // 10 - Encerrar  
    case "10":
        console.log("FIM");
        break;

}